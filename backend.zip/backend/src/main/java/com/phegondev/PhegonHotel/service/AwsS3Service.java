package com.phegondev.PhegonHotel.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class AwsS3Service {

	public String saveImage(MultipartFile photo) {
			String fileName = UUID.randomUUID() + "_" + photo.getOriginalFilename();
			Path uploadPath = Paths.get("uploads/");
			if (!Files.exists(uploadPath)) {
				try {
					Files.createDirectories(uploadPath);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			Path filePath = uploadPath.resolve(fileName);
			try {
				Files.copy(photo.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				e.printStackTrace();
			}
			String imageUrl = "http://localhost:4040/uploads/" + fileName.replace("\\", "/");
			return imageUrl;
	}
}
